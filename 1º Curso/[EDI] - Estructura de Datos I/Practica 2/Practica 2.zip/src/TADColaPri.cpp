#include "TADColaPri.h"
#include "fstream"

ColaPri::ColaPri(){ //Constructor: crea un objeto ColaPri vac�o
    delete [] tabla;
    for(int i=0;i<MAXcolas;i++){
        if (!tabla[i].esvacia()){
            //for(int j=0;j<tabla[i].longitud();j++){
            while(!tabla[i].esvacia()){
                tabla[i].desencolar();
            }
        }
    }
}

ColaPri::~ColaPri(){ //Destructor: libera la memoria din�mica del objeto ColaPri
    delete [] tabla;
}

void ColaPri::insertarColaPri(int i, Paciente p){
/*Insertar� el paciente p en la cola de prioridad i de la ColaPri*/
    tabla[i].encolar(p);
}

void ColaPri::sacarColaPri(){
/*Elimina el paciente de mayor prioridad. Si hay varios con la misma
prioridad saldr� aquel que lleve m�s tiempo en el objeto ColaPri*/
    if(!esvaciaColaPri()){
        int i=0;
        while(tabla[i].esvacia() && i<9){
            i++; //para colocarnos en la tabla tabla de mayor prioridad que no est� vac�a
        }
        //OBTENEMOS EN i LA PRIMERA PRIORIDAD Q NO ESTA VACIA

        if(i<9) //si i<9 quiere decir que no est� todo vac�o
            tabla[i].desencolar();
    }
    else
        cout<<"No hay nada que desencolar";

}

Paciente ColaPri::consultarColaPri(){
/*Devuelve el paciente de mayor prioridad almacenado en el objeto ColaPri
original sin quitarlo. Si hay varios con la misma prioridad saldr� aquel
que lleve m�s tiempo en el objeto ColaPri*/
    Paciente pac;

    int i=0;
    while(tabla[i].esvacia()){
        i++; //para colocarnos en la tabla tabla de mayor prioridad que no est� vac�a
    }

    pac=tabla[i].primero();

    return pac;
}

bool ColaPri::esvaciaColaPri(){//Devuelve si el objeto ColaPri est� vac�o
    bool vacio=false;

    int i=0;
    while(tabla[i].esvacia() && i<9){
        i++; //para colocarnos en la tabla tabla de mayor prioridad que no est� vac�a
    }

    if(i==9)
        vacio=true;

    return vacio;
}

int ColaPri::longitudColaPri(){//Devuelve la longitud del objeto ColaPri
    int n=0;
    int i=0;

    while(i<9){
        if(!tabla[i].esvacia()){
            n=n+tabla[i].longitud(); //suma numeros de elementos en la prioridad actual
        }
        i++;
    }

    return n;
}

bool ColaPri::cargarfichero (cadena fich){
/*Cargar� los datos almacenados en el fichero cuyo nombre se pasa como
par�metro en el objeto ColaPri. Devuelve true si no hay error en la carga*/
    bool cargado=false;

    fstream fichero;
    fichero.open(fich, ios::binary | ios::in | ios::out);

    if(fichero.fail()){
        cargado=false;
        fichero.clear();
    }
    else{
        Paciente aux;

        fichero.seekg(0,ios::beg); //al inicio

        fichero.read((char*)&aux,sizeof(Paciente)); //lectura anticipada

        while(!fichero.eof()){
            if(aux.edad<=9){ //priori1
                tabla[0].encolar(aux);
            }
            else if(aux.edad<=19){ //priori2
                tabla[1].encolar(aux);
            }
            else if(aux.edad<=29){ //priori3
                tabla[2].encolar(aux);
            }
            else if(aux.edad<=39){ //priori4
                tabla[3].encolar(aux);
            }
            else if(aux.edad<=49){ //priori5
                tabla[4].encolar(aux);
            }
            else if(aux.edad<=59){ //priori6
                tabla[5].encolar(aux);
            }
            else if(aux.edad<=69){ //priori7
                tabla[6].encolar(aux);
            }
            else if(aux.edad<=79){ //priori8
                tabla[7].encolar(aux);
            }
            else{  //priori 9
                tabla[8].encolar(aux);
            }

            fichero.read((char*)&aux,sizeof(Paciente));
        }
        cargado=true;
    }

    fichero.close();

    return cargado;
}

bool ColaPri::guardarfichero (cadena fich){
/*Guardar� los datos del objeto ColaPri en el fichero cuyo nombre se pase
como par�metro. Devuelve true si no hay error al guardar el objeto*/
    bool guardado=false;

    fstream fichero;
    fichero.open(fich, ios::binary | ios::in | ios::out);

    if(fichero.fail()){ //si no se abre==no existe -> crear fichero
            fichero.clear();
            fichero.close();
            fichero.open("Autobuses.dat", ios::out | ios::binary); //se abre en escritura para crear el fichero
            fichero.close();
    }
        fichero.seekg(0,ios::beg);
        int i=0;
        Paciente pac;
        cola aux;

        while(i<MAXcolas){ //bucle para ir escribiendo todos los autobuses q hay
            aux=tabla[i];
            while(!aux.esvacia()){
                pac=aux.primero();
                fichero.write((char*) &pac, sizeof(Paciente)); //escribe el paciente
                aux.desencolar();
                i++;
            }
        }
        //guardado=true;

    if(!fichero.fail())
        guardado=true;
    else
        fichero.clear();

    fichero.close();

    return guardado;
}
