#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>

using namespace std;

#define NUMCARS 29

typedef char carmorse[7];

char letras[NUMCARS]    = {' ',',','.','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
carmorse morse[NUMCARS] = {" ","--..--",".-.-.-",".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."};

struct alfabetos {
    char letra;
    carmorse morse;
};

class traductor {
    alfabetos caracteres[NUMCARS];
public:
  traductor(){
    for(int i=0;i<NUMCARS;i++)
    {
        caracteres[i].letra=letras[i];
        strcpy(caracteres[i].morse,morse[i]);
    }
  }

  void codificar(){
    char msg[200];
    int encontrado;
    cout<<"Introduzca el mensaje a codificar:\n";
    cin>>msg;
    cout<<"La cadena a convertir es: ";

    for(int i=0;i<strlen(msg);i++)
    {
        cout<<msg[i];
    }

    cout<<endl;

    cout<<"En Morse, dicha cadena es: ";

    for(int i=0;i<strlen(msg);i++)
    {
        encontrado=buscacar(msg[i]);
        if (encontrado>=0)
        {
            cout<<caracteres[encontrado].morse<<" ";
        }
        else
            cout<<"X ("<<msg[encontrado]<<")";
    }
    cout<<endl;
  }

  void codificardirecta(){
    char msg[200];
    int encontrado;
    cout<<"Introduzca el mensaje a codificar:\n";

    /*while()
    {
        cin>>msg;
    }*/

    /*for(int i=0;i<strlen(msg);i++)
    {
        int encontrado=buscacar(msg[i]);
        if (encontrado>=0)
        {
            cout<<caracteres[i].morse;
        }
        else
            cout<<"X ("<<msg[i]<<")";
    }*/

  }

  int buscacar(char car){

    int encontrado=1;
    int i=0;

    do{
        if (car==caracteres[i].letra)
        {
            encontrado=i;
        }
        else
        {
            i++;
        }
    }while((i<NUMCARS)&&(encontrado==1));

    return encontrado;
  }
  void mostrar(){
        for(int i=0;i<NUMCARS;i)
        {
              cout<<setw(7)<<caracteres[i].letra<<setw(7)<<caracteres[i].morse<<"      ";
        }
  }
};

int main()
{
    traductor practica;
    int menu=1;



    do{
        cout<<"1. CODIFICAR (Texto a Morse)\n";
        cout<<"2. CODIFICAR DIRECTO (Texto a Morse)\n";
        cout<<"3. MOSTRAR EL ALFABETO MORSE\n";
        cout<<"4. SALIR...\n";
        cout<<"\nIntroduza opcion del menu (1...4): ";
        cin>>menu;
        cout<<endl;

        switch(menu)
        {
            case 1: {practica.codificar();
                    break;}
            case 2: {//practica.codificardirecta();
                    cout<<"Funci�n en desarrollo";
                    break;}
            case 3: {practica.mostrar();
                    break;}
            default: cout<<"Seleccione una opcion del menu valida\n";
        }
    }while(menu!=4);
    return 0;
}
