#include "cartelera.h"
#include <iostream>  

using namespace std; 
 
Cartelera::Cartelera(): espectaculos() 
{
}

void Cartelera::insertaEspectaculo(const string& e)
{


} 
                       
void Cartelera::insertaSala(const string& e, const string& s, const string& c)
{


}

void Cartelera::eliminaEspectaculo(const string& e)
{
   
   
}

void Cartelera::eliminaSala(const string& e, const string& s)
{
    
    
}

void Cartelera::listaEspectaculos()
{
    
    
}

void Cartelera::listaSalas(const string& e)
{
     
     
}

